cp.playbarAssetArr = 
[
	'AudioOff',
	'AudioOn',
	'BackGround',
	'Backward',
	'Color',
	'ColorSmall',
	'CC',
	'Exit',
	'FastForward',
	'FastForward1',
	'FastForward2',
	'Forward',
	'Glow',
	'GlowSmall',
	'Height',
	'InnerStroke',
	'InnerStrokeSmall',
	'Play',
	'Pause',
	'Progress',
	'Rewind',
	'Shade',
	'ShadeSmall',
	'Stroke',
	'StrokeSmall',
	'Thumb',
	'ThumbBase',
	'TOC'
];
cp.playbarTooltips = 
{
	AudioOff : "Audio act.",
	AudioOn : "Audio desact. ",
	Backward : "Atrás ",
	CC : "Subtítulos opcionales ",
	Exit : "Salir ",
	FastForward : "Velocidad de avance rápido 2x ",
	FastForward1 : "Velocidad de avance rápido 4x ",
	FastForward2 : "Velocidad normal ", 
	Forward : "Adelante ",
	Play : "Reproducir ",
	Pause : "Pausa ",
	Rewind : "Rebobinar ",
	TOC : "Contenido ",
	Info : "Información ",
	Print : "Imprimir "
};
cp.handleSpecialForPlaybar = function(playbarConstruct)
{
}